// Example: simple button click event
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("clickBtn");

  btn.addEventListener("click", () => {
    alert("Hello! You clicked the button 🚀");
  });
});
